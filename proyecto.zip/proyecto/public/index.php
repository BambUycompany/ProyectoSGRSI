<?php
require_once __DIR__ . "/../config/config.php";
require_once RUTA_NUCLEO . "/bootstrap.php";
?>