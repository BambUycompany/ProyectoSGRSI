const PAGINAS_POR_ROL = {
    administrador: "./administrador.html",
    soporte: "./soporte.html",
    solicitante: "./solicitante.html"
};

const contenedorOpciones = document.getElementById("opcionesRol");
const roles = JSON.parse(sessionStorage.getItem("roles") ?? "[]");

function elegirRol(rol) {
    sessionStorage.setItem("rolActivo", rol);
    window.location.replace(PAGINAS_POR_ROL[rol]);
}

function mostrarOpciones() {
    if (roles.length === 0) {
        window.location.replace("./login.html");
        return;
    }

    if (roles.length === 1) {
        elegirRol(roles[0]);
        return;
    }

    for (const rol of roles) {
        const boton = document.createElement("button");
        boton.type = "button";
        boton.classList.add("botones");
        boton.textContent = rol.charAt(0).toUpperCase() + rol.slice(1);
        boton.addEventListener("click", () => elegirRol(rol));
        contenedorOpciones.appendChild(boton);
    }
}

mostrarOpciones();